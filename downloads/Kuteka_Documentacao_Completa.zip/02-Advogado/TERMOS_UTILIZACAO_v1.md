# Termos e Condições de Utilização da Plataforma Kuteka

**Versão 1.0 Beta · Vigência 5 de Agosto de 2026 · Operador: plataforma Kuteka (kutekalink.com) · Contactos: contacto@kutekalink.com · juridico@kutekalink.com**

---

> **Aviso preliminar.** O presente documento é emitido para a plataforma Kuteka na sua versão 1.0 Beta. Rege-se pela lei da República de Angola. Quaisquer litígios emergentes da sua interpretação ou execução serão dirimidos preferencialmente pelos tribunais da Comarca de Luanda, privilegiando-se sempre, em primeiro lugar, a resolução amigável entre as partes. Por se tratar de uma versão em fase Beta, os presentes textos podem ser actualizados a qualquer momento; a continuação da utilização da plataforma após a publicação de uma nova versão constitui aceitação plena e sem reservas da versão então em vigor.

---

## 1. Identificação e aceitação

A plataforma Kuteka, acessível através do endereço electrónico kutekalink.com e respectivas aplicações e subdomínios (adiante designada, indistintamente, por «Kuteka», «Plataforma» ou «Operador»), é um serviço tecnológico de intermediação no domínio imobiliário e patrimonial, disponibilizado no território da República de Angola e destinado a clientes, parceiros patrimoniais, agentes certificados e prestadores de serviços.

Os presentes Termos e Condições de Utilização (adiante «Termos») constituem o contrato que regula, de forma vinculativa, a relação entre a Kuteka e qualquer pessoa singular ou colectiva que aceda, registe conta, navegue ou de qualquer modo utilize a Plataforma (adiante «Utilizador»). A aceitação dos Termos ocorre no momento em que o Utilizador cria a sua conta, assinala a caixa de aceitação, ou, na falta destes actos, no momento em que inicia a utilização de qualquer funcionalidade da Plataforma. Ao praticar qualquer destes actos, o Utilizador declara ter lido, compreendido e aceite integralmente o presente documento, bem como os demais textos que o complementam, designadamente a Política de Privacidade.

Caso o Utilizador não concorde, no todo ou em parte, com o disposto nos presentes Termos, deve abster-se de utilizar a Plataforma e, existindo conta registada, proceder ao seu encerramento. A utilização continuada equivale, para todos os efeitos, à aceitação da versão publicada e vigente em cada momento.

## 2. Definições

Para efeitos dos presentes Termos, e sempre que iniciados por maiúscula, os termos que se seguem têm o significado que aqui lhes é atribuído, sem prejuízo do sentido que o contexto lhes imponha:

- **Cliente** — pessoa singular ou colectiva que utiliza a Plataforma com o propósito de procurar, arrendar, comprar, contratar serviços ou de qualquer modo aceder à oferta patrimonial e de serviços disponibilizada por terceiros na Kuteka.
- **Parceiro Patrimonial** — pessoa singular ou colectiva, tipicamente institucional (por exemplo, promotor, proprietário de carteira imobiliária, fundo ou empresa de gestão de activos), que disponibiliza patrimónios, anúncios ou carteiras na Plataforma ao abrigo de condições preferenciais de natureza B2B.
- **Agente Certificado** — profissional ou entidade habilitada e verificada pela Kuteka para mediar, publicar e acompanhar anúncios e negócios em nome próprio ou de terceiros, sujeito a critérios de certificação e a deveres reforçados de conduta.
- **Prestador** — pessoa singular ou colectiva que oferece, através do Marketplace da Plataforma, serviços conexos ao domínio patrimonial (por exemplo, mudanças, limpeza, manutenção, assistência técnica ou serviços de concierge).
- **Administrador** — colaborador ou entidade a quem a Kuteka atribui poderes de gestão operacional sobre determinados conteúdos, contas ou processos da Plataforma, nos limites do perfil que lhe é conferido.
- **Super Administrador** — nível máximo de administração da Plataforma, competindo-lhe, designadamente, a parametrização de preços, comissões, planos, políticas e regras de negócio globais.
- **KIS** — _Kuteka Identity System_, o sistema de identidade e verificação da Plataforma, que suporta os processos de conhecimento e validação do Utilizador (KYC) e a atribuição progressiva de níveis de confiança.
- **Kuteka Pay** — o motor de pagamentos único da Plataforma, através do qual são processadas, orquestradas e registadas as operações financeiras suportadas pela Kuteka, mediante integração com gateways de pagamento.
- **Ledger** — o registo interno, estruturado e auditável, de movimentos, transacções, créditos, comissões e demais lançamentos associados às operações da Plataforma, com finalidade de rastreabilidade e reconciliação.
- **Anúncio** — a publicação, por um Utilizador habilitado, de um património, imóvel, oferta ou serviço na Plataforma, com a respectiva descrição, condições e elementos multimédia.
- **Contrato** — o instrumento que as partes formalizam através das ferramentas da Plataforma, cuja validade e eficácia jurídica dependem da lei aplicável e da vontade e capacidade das partes que o subscrevem.
- **Comissão** — o valor devido à Kuteka, ou por seu intermédio, em razão da intermediação, publicação, conclusão de negócio ou prestação de serviços, calculado nos termos da tabela e dos planos em vigor.
- **Créditos Kuteka** — unidades internas de utilização da Plataforma que permitem aceder a determinadas funcionalidades ou serviços, sem constituírem dinheiro depositado, moeda com curso legal, nem valor mobiliário.
- **Sandbox versus Produção** — «Sandbox» designa o ambiente de teste, simulação e ensaio, sem efeitos financeiros reais, no qual decorrem, na presente fase Beta, as operações de pagamento; «Produção» designa o ambiente operacional real, com efeitos financeiros efectivos, cuja activação plena será oportunamente comunicada.

## 3. Objecto e natureza da plataforma

A Kuteka é uma plataforma de **intermediação tecnológica**. O seu objecto consiste em disponibilizar um ambiente digital que aproxima Clientes, Parceiros Patrimoniais, Agentes Certificados e Prestadores, facilitando a divulgação de anúncios, a comunicação entre partes, a formalização de contratos e o processamento de pagamentos através de meios integrados. A Kuteka actua, por regra, como facilitadora tecnológica e não como parte nos negócios celebrados entre os Utilizadores, salvo naquilo em que expressamente preste serviços próprios.

A Kuteka **não é uma instituição bancária nem financeira**, não capta depósitos, não concede crédito e não exerce qualquer actividade sujeita a reserva legal do sector bancário ou financeiro. As referências a pagamentos, créditos ou ledger têm natureza estritamente operacional e destinam-se à orquestração e ao registo das operações suportadas pela Plataforma.

A Kuteka **não presta serviços de custódia** de fundos nesta fase. O modo de custódia encontra-se, na versão 1.0 Beta, definido como `custody_mode=none`, o que significa que a Plataforma não retém, guarda nem administra fundos de terceiros em regime de carteira ou de garantia (_escrow_). Os fluxos financeiros, quando ocorram em ambiente de produção, processam-se através dos gateways de pagamento integrados, sem constituição de saldo custodiado pela Kuteka.

A Kuteka **não é cartório, conservatória, notário nem entidade registral**. As ferramentas de formalização de contratos disponibilizadas destinam-se a facilitar a documentação da vontade das partes e não substituem, dispensam ou suprem quaisquer formalidades notariais, registais ou de reconhecimento que a lei angolana exija para a validade ou eficácia de determinados actos, designadamente em matéria de transmissão da propriedade imóvel.

## 4. Elegibilidade e registo de conta

A utilização da Plataforma com conta registada está reservada a pessoas singulares maiores de dezoito anos, com capacidade jurídica plena, e a pessoas colectivas legalmente constituídas e devidamente representadas. Ao registar-se, o Utilizador declara reunir estes requisitos e garante a veracidade, exactidão e actualidade de todos os dados fornecidos.

O registo implica a criação de credenciais de acesso e pode exigir a validação de contacto (telefónico ou de correio electrónico) mediante código de uso único, bem como a submissão a processos de verificação de identidade no âmbito do KIS, nos termos da secção 10. A Kuteka reserva-se o direito de recusar, condicionar ou suspender registos que não cumpram os requisitos de elegibilidade, que apresentem indícios de fraude ou que violem os presentes Termos ou a lei aplicável.

Cada Utilizador é responsável por manter os seus dados de registo actualizados e por comunicar, com prontidão, qualquer alteração relevante. A prestação de informações falsas, incompletas ou enganosas no momento do registo, ou em momento posterior, constitui violação grave dos presentes Termos e legitima a aplicação das sanções previstas na secção 23.

## 5. Papéis e multi-papel

A Plataforma organiza-se em torno de papéis funcionais, designadamente os de Cliente, Parceiro Patrimonial, Agente Certificado, Prestador, Administrador e Super Administrador. A cada papel corresponde um conjunto próprio de permissões, funcionalidades, deveres e responsabilidades.

Um mesmo Utilizador pode, quando a Plataforma o permita e os requisitos aplicáveis se encontrem preenchidos, acumular mais do que um papel (**multi-papel**). Neste caso, o Utilizador fica sujeito, em simultâneo e de forma cumulativa, às regras e deveres inerentes a cada um dos papéis que exerce, devendo actuar em cada contexto com a diligência e a boa-fé próprias da posição em causa. A acumulação de papéis não pode ser utilizada para contornar limites, comissões, verificações ou proibições estabelecidas nos presentes Termos.

Os papéis de Administrador e de Super Administrador são atribuídos exclusivamente pela Kuteka, no âmbito da sua organização interna, e não são acessíveis por simples registo. O exercício destes papéis está sujeito a deveres reforçados de confidencialidade, integridade e diligência.

## 6. Regras de utilização aceitável e proibições

O Utilizador obriga-se a utilizar a Plataforma de forma lícita, diligente e de boa-fé, no respeito pela lei angolana, pelos direitos de terceiros e pelos presentes Termos. É expressamente proibido, a título exemplificativo e não taxativo:

- Publicar anúncios falsos, enganosos, duplicados, ou relativos a patrimónios inexistentes, indisponíveis ou sobre os quais o Utilizador não detenha legitimidade;
- Usurpar identidade alheia, prestar informações falsas ou manipular os processos de verificação do KIS;
- Contornar o Kuteka Pay, aliciar contrapartes a concluir negócios fora da Plataforma com o intuito de evitar comissões, ou de qualquer modo defraudar o Operador ou outros Utilizadores;
- Publicar conteúdos ilícitos, difamatórios, discriminatórios, violentos, obscenos ou que violem direitos de propriedade intelectual de terceiros;
- Utilizar a Plataforma para fins de branqueamento de capitais, financiamento ilícito ou qualquer outra actividade proibida por lei;
- Recolher dados de outros Utilizadores sem fundamento legítimo, praticar _scraping_ não autorizado, ou introduzir vírus, código malicioso ou mecanismos que comprometam a segurança ou o funcionamento da Plataforma;
- Tentar aceder, sem autorização, a áreas restritas, contas alheias ou infra-estruturas da Kuteka.

A violação das presentes regras confere à Kuteka o direito de remover conteúdos, restringir funcionalidades, suspender ou encerrar contas e adoptar as demais medidas previstas na secção 23, sem prejuízo da responsabilidade civil e criminal do infractor.

## 7. Anúncios e patrimónios

O Utilizador que publica anúncios é o único responsável pela **exactidão, veracidade, completude e actualidade** das informações que disponibiliza, designadamente quanto à localização, características, área, estado de conservação, situação jurídica, preço e condições do património anunciado.

As **fotografias** e demais elementos multimédia devem corresponder fielmente ao património real, ser actuais e não induzir em erro. É proibida a utilização de imagens que não representem o bem efectivamente anunciado ou que ocultem defeitos relevantes.

O Utilizador obriga-se a assegurar e manter actualizada a **disponibilidade** do património anunciado, retirando ou marcando como indisponível o anúncio logo que o bem deixe de estar disponível. A Kuteka pode, no âmbito das suas funções de moderação, remover ou suspender anúncios que se revelem falsos, desactualizados, duplicados ou desconformes com os presentes Termos, sem que tal implique qualquer responsabilidade sua perante o anunciante.

## 8. Habitação — propostas, visitas e intenções

No domínio da habitação, a Plataforma disponibiliza ferramentas que permitem ao Cliente manifestar interesse, submeter **propostas**, agendar **visitas** e registar **intenções** relativamente a patrimónios anunciados. Estes actos têm, por regra, natureza preliminar e não vinculativa, salvo se, do seu conteúdo e da vontade expressa das partes, resultar o contrário, nos termos da lei geral.

O agendamento e a realização de visitas dependem da disponibilidade e da concordância do anunciante ou do agente responsável. A Kuteka não garante a realização de visitas nem a aceitação de propostas, limitando-se a facilitar a comunicação e a organização entre as partes. As partes obrigam-se a actuar com pontualidade, respeito e boa-fé na marcação e realização de visitas.

O registo de uma intenção ou proposta na Plataforma não substitui a celebração dos contratos legalmente exigíveis nem confere, por si só, qualquer direito sobre o património, sem prejuízo dos efeitos que a lei atribua a declarações negociais quando revistam os requisitos legais.

## 9. Contratos na plataforma

A Kuteka disponibiliza ferramentas de **formalização de contratos** que auxiliam as partes na documentação, estruturação e assinatura dos acordos que entre si pretendam celebrar. Estas ferramentas constituem um instrumento de apoio de natureza tecnológica.

A **validade e a eficácia jurídica** de qualquer contrato formalizado através da Plataforma dependem, exclusivamente, do cumprimento dos requisitos legais aplicáveis e da vontade, capacidade e legitimidade das partes que o subscrevem. A Kuteka não é parte nos contratos celebrados entre Utilizadores, não garante a sua validade, exequibilidade ou cumprimento, e não assume responsabilidade pelo incumprimento das obrigações que deles emirjam.

Sempre que a lei angolana exija forma especial, intervenção notarial, reconhecimento de assinaturas, registo ou qualquer outra formalidade para a validade ou eficácia de um acto — designadamente em matéria de compra e venda ou oneração de bens imóveis —, essas formalidades devem ser observadas pelas partes fora da Plataforma, não sendo supridas pelas ferramentas aqui disponibilizadas.

## 10. KIS, KYC e verificação de identidade

A Plataforma integra o **Kuteka Identity System (KIS)**, que suporta os processos de conhecimento do Utilizador (_Know Your Customer_ — KYC) e de verificação de identidade. Estes processos visam prevenir a fraude, proteger os Utilizadores, garantir a integridade das operações e cumprir as obrigações legais e regulamentares aplicáveis.

A verificação de identidade tem **obrigatoriedade progressiva**: o acesso a determinadas funcionalidades, níveis de operação, valores de transacção ou papéis na Plataforma pode ficar condicionado à conclusão bem-sucedida de níveis crescentes de verificação. A Kuteka pode solicitar, em qualquer momento, documentos de identificação, comprovativos e demais elementos necessários à validação da identidade e da legitimidade do Utilizador.

A prestação de informações ou documentos **falsos, adulterados ou enganosos**, bem como a tentativa de contornar ou manipular o KIS, constitui infracção grave e determina a aplicação de sanções, que podem incluir a recusa ou reversão de operações, a suspensão ou o encerramento imediato da conta e a comunicação às autoridades competentes, sem prejuízo da responsabilidade civil e criminal do infractor.

## 11. Kuteka Pay e pagamentos

O **Kuteka Pay** é o **único motor de pagamentos** da Plataforma. Todas as operações financeiras suportadas pela Kuteka são orquestradas e registadas através do Kuteka Pay, sendo proibido o desvio de pagamentos para meios externos com o intuito de contornar comissões, verificações ou registos.

O processamento efectivo dos pagamentos é realizado através de **gateways** de pagamento integrados, aos quais podem aplicar-se termos próprios dos respectivos operadores. A Kuteka actua como orquestradora e não como detentora dos fundos.

Na presente **fase Beta**, as operações de pagamento decorrem em ambiente **sandbox**, isto é, em modo de teste e simulação, sem efeitos financeiros reais. A transição para o ambiente de produção, com efeitos financeiros efectivos, será oportunamente comunicada aos Utilizadores.

Nesta fase, e em conformidade com o modo `custody_mode=none`, a Kuteka **não disponibiliza carteira (_wallet_) nem serviço de garantia (_escrow_)**, não retendo nem administrando saldos de fundos de terceiros. O Ledger regista os movimentos com finalidade de rastreabilidade e reconciliação, não constituindo depósito nem saldo mobilizável fora da Plataforma.

## 12. Preços, comissões e planos

Os preços, comissões, taxas e planos aplicáveis à utilização da Plataforma são definidos e **parametrizados pelo Super Administrador**, podendo ser consultados nas áreas próprias da Plataforma e sendo actualizados de acordo com a política comercial em vigor.

O modelo comercial assenta, por regra, num regime de **pagamento por utilização** (_pay-per-use_), no qual o Utilizador paga em função das funcionalidades e serviços que efectivamente utiliza. A Plataforma pode disponibilizar, de forma **opcional**, um plano de subscrição **Plus**, que confere condições, funcionalidades ou vantagens acrescidas, mediante contrapartida periódica.

Aos Parceiros Patrimoniais e a determinados Utilizadores institucionais podem aplicar-se **comissões B2B preferenciais**, definidas caso a caso ou por segmento, no âmbito da política comercial da Kuteka. As condições preferenciais não são transmissíveis e vigoram apenas enquanto se mantiverem os pressupostos que as fundamentam.

A Kuteka reserva-se o direito de alterar preços, comissões e planos, comunicando as alterações com antecedência razoável. As alterações não têm efeito retroactivo sobre operações já concluídas e a continuação da utilização após a entrada em vigor das novas condições constitui aceitação das mesmas.

## 13. Créditos Kuteka

Os **Créditos Kuteka** são unidades internas de utilização que permitem aceder a determinadas funcionalidades ou serviços da Plataforma. Os Créditos **não constituem dinheiro depositado**, não são moeda com curso legal, não vencem juros e não conferem qualquer direito de reembolso em numerário, salvo quando os presentes Termos ou a política aplicável expressamente o prevejam.

Os Créditos **não são transferíveis para fora da Plataforma**, nem cedíveis a terceiros, salvo nos casos e nos termos que uma política específica da Kuteka venha a admitir. A sua utilização está sujeita às regras, prazos de validade e condições que a Kuteka estabelecer e comunicar.

A obtenção fraudulenta, o uso indevido ou a tentativa de conversão irregular de Créditos constituem violação dos presentes Termos e legitimam a sua anulação, bem como a adopção das demais medidas previstas na secção 23.

## 14. Cancelamentos e reembolsos

As condições de cancelamento e de reembolso dependem do estado de execução do serviço ou operação no momento do pedido, bem como da existência ou não de defeito ou de fraude. Aplica-se, com carácter geral, a seguinte tabela de regras:

| Situação no momento do pedido              | Regra de reembolso                                                                                        |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------- |
| Antes de iniciada a execução do serviço    | Reembolso total, em numerário (pelo meio originário) ou em Créditos Kuteka, conforme a política aplicável |
| Serviço em curso (execução parcial)        | Reembolso parcial, proporcional à parte ainda não executada, deduzidos os custos já incorridos            |
| Serviço concluído                          | Sem direito a reembolso, salvo verificação de defeito imputável ao prestador ou à Kuteka                  |
| Situação de fraude imputável ao Utilizador | Sem direito a reembolso, sem prejuízo das demais sanções e da responsabilidade legal                      |

O pedido de cancelamento deve ser efectuado através dos meios disponibilizados na Plataforma. O apuramento da execução parcial, da existência de defeito e da eventual fraude é realizado pela Kuteka de forma fundamentada, podendo ser solicitados elementos comprovativos ao Utilizador. Os reembolsos, quando devidos, são processados através do Kuteka Pay, pelo meio originário de pagamento ou em Créditos Kuteka, consoante a política aplicável e a natureza da operação. Nada no presente número prejudica os direitos que a lei angolana reconheça imperativamente ao consumidor.

## 15. Serviços comerciais

A Kuteka pode disponibilizar, directamente ou através de Prestadores e Parceiros, um conjunto de serviços comerciais conexos ao domínio patrimonial, designadamente:

- **Mudança Inteligente** — organização e coordenação de serviços de mudança e transporte de bens;
- **Encontrar Casa** — apoio personalizado à procura e selecção de habitação, de acordo com os critérios do Cliente;
- **Concierge** — serviços de acompanhamento e assistência personalizada em processos patrimoniais;
- **Garantia Kuteka** — mecanismos de reforço de confiança e protecção em determinadas operações, nos termos e limites que forem especificamente definidos;
- **Assistência 24h** — apoio de disponibilidade alargada para situações urgentes, nos termos do respectivo serviço;
- **Marketplace de prestadores** — ambiente de intermediação que aproxima Clientes de Prestadores de serviços conexos.

A **natureza e as responsabilidades** de cada serviço variam consoante seja prestado directamente pela Kuteka ou por terceiros. Quando o serviço for prestado por um Prestador ou Parceiro, a Kuteka actua como intermediária tecnológica, sendo o Prestador ou Parceiro o responsável directo pela execução, qualidade e conformidade do serviço. Quando o serviço for prestado directamente pela Kuteka, esta responde nos termos gerais e dentro dos limites estabelecidos nos presentes Termos e na lei aplicável. As condições específicas de cada serviço, incluindo âmbito, preço e limites, são as que constarem da respectiva descrição na Plataforma no momento da contratação.

## 16. Conteúdos do utilizador e licença à Kuteka

O Utilizador mantém a titularidade dos conteúdos que carrega, publica ou de outro modo disponibiliza na Plataforma (designadamente textos, descrições, fotografias e demais elementos — os «Conteúdos do Utilizador»), garantindo que dispõe de todos os direitos necessários para o efeito e que tais conteúdos não violam direitos de terceiros nem a lei.

Ao disponibilizar Conteúdos do Utilizador, este concede à Kuteka uma **licença** não exclusiva, gratuita, válida para o território em que a Plataforma opera e pelo tempo necessário à prestação do serviço, para armazenar, reproduzir, adaptar tecnicamente, exibir e divulgar tais conteúdos no âmbito do funcionamento, promoção e melhoria da Plataforma. Esta licença cessa, quanto aos conteúdos removidos, com a sua eliminação, sem prejuízo da conservação de cópias exigida por lei ou necessária para efeitos de prova, segurança ou cumprimento de obrigações legais.

O Utilizador é o único responsável pelos Conteúdos do Utilizador que disponibiliza e responde por quaisquer danos ou reclamações deles resultantes. A Kuteka pode remover ou bloquear conteúdos que considere ilícitos, desconformes com os presentes Termos ou lesivos de direitos de terceiros.

## 17. Propriedade intelectual Kuteka

Todos os direitos de propriedade intelectual e industrial relativos à Plataforma, incluindo a marca «Kuteka», o nome de domínio, os logótipos, o código-fonte, a arquitectura, o desenho, as bases de dados, os textos, os elementos gráficos e demais componentes, pertencem à Kuteka ou aos seus licenciantes, e encontram-se protegidos pela lei aplicável.

Os presentes Termos não conferem ao Utilizador qualquer direito de propriedade sobre a Plataforma, mas apenas um direito de utilização limitado, pessoal, revogável e não transmissível, estritamente para os fins previstos. É proibida a reprodução, distribuição, modificação, engenharia inversa, exploração comercial ou qualquer outra utilização não autorizada dos elementos protegidos, salvo autorização expressa e escrita da Kuteka ou nos limites imperativos da lei.

## 18. Privacidade

O tratamento de dados pessoais no âmbito da utilização da Plataforma rege-se pela **Política de Privacidade** da Kuteka, que constitui parte integrante do enquadramento contratual e que o Utilizador declara conhecer e aceitar. A Política de Privacidade descreve, designadamente, as categorias de dados tratados, as finalidades, os fundamentos de licitude, os prazos de conservação, as comunicações a terceiros e os direitos do titular dos dados, em conformidade com a legislação angolana de protecção de dados pessoais. Em caso de dúvida sobre matérias de privacidade, o Utilizador pode contactar a Kuteka através de contacto@kutekalink.com.

## 19. Segurança da conta

O Utilizador é responsável por manter a **confidencialidade e a segurança** das suas credenciais de acesso, não as devendo partilhar com terceiros. A Plataforma disponibiliza mecanismos de reforço de segurança, designadamente a verificação por código de uso único (**OTP**) e a autenticação de dois factores (**2FA**), cuja activação e utilização são vivamente recomendadas e podem ser exigidas para determinadas operações ou papéis.

O Utilizador obriga-se a proteger as suas credenciais, a utilizar palavras-passe robustas e a comunicar imediatamente à Kuteka, através dos contactos indicados, qualquer utilização não autorizada, perda, extravio ou suspeita de comprometimento da sua conta. Presumem-se realizadas pelo Utilizador, e da sua responsabilidade, as operações efectuadas com as suas credenciais, salvo prova de utilização indevida não imputável a falta de diligência sua. A Kuteka pode adoptar medidas de segurança adicionais, incluindo a suspensão preventiva de contas perante indícios de acesso não autorizado.

## 20. Disponibilidade, Beta e limitação de garantias

A Plataforma encontra-se, na presente versão 1.0, em **fase Beta**. Tal significa que algumas funcionalidades podem estar incompletas, sujeitas a alterações, correcções ou interrupções, e que o comportamento da Plataforma pode não ser plenamente estável. O Utilizador aceita utilizar a Plataforma nesta fase com conhecimento e assunção destas características.

A Kuteka envida esforços razoáveis para assegurar a disponibilidade e o bom funcionamento da Plataforma, mas **não garante** o funcionamento ininterrupto, isento de erros ou livre de falhas, podendo ocorrer suspensões para manutenção, actualização, correcção ou por motivos de força maior. Dentro dos limites permitidos pela lei angolana, a Plataforma e os serviços são disponibilizados «no estado em que se encontram» e «conforme disponíveis», não prestando a Kuteka garantias implícitas de adequação a um fim específico que não decorram imperativamente da lei.

## 21. Limitação de responsabilidade

Dentro dos limites permitidos pela **lei angolana**, a responsabilidade da Kuteka circunscreve-se aos danos directos, efectivos e comprovadamente resultantes de incumprimento imputável à Kuteka, ficando excluída, na medida do legalmente admissível, a responsabilidade por danos indirectos, lucros cessantes, perda de oportunidade, perda de dados ou danos consequenciais.

A Kuteka não é responsável pela conduta dos Utilizadores, pela veracidade dos anúncios, pela validade ou cumprimento dos contratos celebrados entre as partes, nem pela qualidade dos serviços prestados por Prestadores ou Parceiros, quando não sejam prestados directamente por si. Do mesmo modo, a Kuteka não responde por falhas imputáveis a terceiros, incluindo gateways de pagamento, operadores de telecomunicações ou fornecedores de infra-estrutura, nem por eventos de força maior.

Nada nos presentes Termos exclui ou limita a responsabilidade da Kuteka nos casos em que tal exclusão ou limitação seja proibida pela lei angolana imperativa, designadamente em caso de dolo ou culpa grave, ou perante direitos irrenunciáveis do consumidor.

## 22. Indemnização

O Utilizador obriga-se a indemnizar e a manter indemne a Kuteka, os seus administradores, colaboradores e parceiros, por quaisquer danos, perdas, custos, encargos ou despesas (incluindo despesas razoáveis com patrocínio jurídico) que resultem, directa ou indirectamente, da violação, por parte do Utilizador, dos presentes Termos, da lei aplicável ou de direitos de terceiros, bem como da utilização indevida da Plataforma. A Kuteka reserva-se o direito de assumir a defesa e o controlo de qualquer questão sujeita a indemnização, caso em que o Utilizador cooperará razoavelmente com a Kuteka.

## 23. Suspensão e encerramento de conta

A Kuteka pode, de forma fundamentada e proporcional, **suspender ou encerrar** a conta de um Utilizador, remover conteúdos ou restringir funcionalidades sempre que se verifique violação dos presentes Termos ou da lei, prestação de informações falsas, prática ou indício de fraude, risco para a segurança da Plataforma ou de terceiros, ou determinação de autoridade competente.

Sempre que possível e adequado, a Kuteka comunicará ao Utilizador a medida adoptada e os respectivos fundamentos, podendo, consoante a gravidade, aplicar medidas menos gravosas antes do encerramento. Em situações de risco iminente ou de infracção grave, a Kuteka pode aplicar medidas imediatas, incluindo a suspensão preventiva.

O Utilizador pode, a todo o tempo, solicitar o encerramento da sua conta através dos meios disponibilizados. O encerramento não prejudica as obrigações vencidas nem os efeitos das operações já concluídas, e a Kuteka conservará os dados que a lei imponha ou que sejam necessários para efeitos de prova, segurança ou cumprimento de obrigações legais.

## 24. Alterações aos Termos

Por se tratar de uma versão em fase Beta e por força da evolução da Plataforma, do enquadramento legal e da política comercial, a Kuteka pode **actualizar os presentes Termos** a qualquer momento. As alterações serão publicadas na Plataforma, com indicação da respectiva versão e data de vigência.

A **continuação da utilização** da Plataforma após a entrada em vigor de uma nova versão constitui aceitação plena e sem reservas dos Termos então publicados. Caso o Utilizador não concorde com as alterações, deve abster-se de continuar a utilizar a Plataforma e, se assim o entender, encerrar a sua conta. As alterações não têm efeito retroactivo sobre operações já concluídas.

## 25. Comunicações

As comunicações da Kuteka ao Utilizador são realizadas através dos meios disponibilizados na Plataforma, designadamente notificações internas, correio electrónico e mensagens para o contacto associado à conta, considerando-se recebidas na data do respectivo envio ou disponibilização. É dever do Utilizador manter os seus contactos actualizados e consultar regularmente as comunicações que lhe sejam dirigidas.

As comunicações do Utilizador à Kuteka devem ser dirigidas aos endereços contacto@kutekalink.com, para assuntos gerais, e juridico@kutekalink.com, para assuntos de natureza jurídica ou contratual. A Kuteka procurará responder num prazo razoável.

## 26. Lei aplicável e foro

Os presentes Termos regem-se pela lei da **República de Angola**. Para a resolução de qualquer litígio emergente da sua interpretação, validade, execução ou cessação, as partes comprometem-se a procurar, em primeiro lugar, uma **resolução amigável** e de boa-fé.

Não sendo possível alcançar acordo, fica eleito, como competente, o foro da **Comarca de Luanda**, com expressa renúncia a qualquer outro, sem prejuízo das normas imperativas de competência que a lei angolana estabeleça, designadamente em matéria de defesa do consumidor.

## 27. Disposições finais

Os presentes Termos, em conjunto com a Política de Privacidade e com as condições específicas de cada serviço ou plano, constituem o **acordo integral** entre a Kuteka e o Utilizador relativamente ao objecto neles versado, prevalecendo sobre quaisquer entendimentos anteriores.

Se alguma disposição dos presentes Termos for considerada inválida, ilegal ou ineficaz, tal não afectará a validade e a eficácia das demais disposições, que se manterão em pleno vigor, procurando-se substituir a disposição afectada por outra que, sendo válida, melhor corresponda à sua finalidade.

A tolerância ou o não exercício, por parte da Kuteka, de qualquer direito ou faculdade previsto nos presentes Termos não constitui renúncia a esse direito nem impede o seu exercício posterior. O Utilizador não pode ceder a sua posição contratual sem consentimento prévio e escrito da Kuteka; esta pode ceder a sua posição no âmbito de reorganização, fusão ou transmissão da actividade, assegurando a manutenção dos direitos do Utilizador.

---

**Luanda, 5 de Agosto de 2026 · Equipa Kuteka**
