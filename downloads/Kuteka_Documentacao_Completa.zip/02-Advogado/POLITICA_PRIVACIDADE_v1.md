# Política de Privacidade — Kuteka

**Versão 1.0 Beta** · **Vigência: 5 de Agosto de 2026** · **Responsável pelo tratamento:** operador da plataforma Kuteka · **Contacto DPO/privacidade:** privacidade@kutekalink.com · **Geral:** contacto@kutekalink.com · **Site:** https://kutekalink.com

---

> **Nota sobre o estatuto Beta.** A plataforma Kuteka encontra-se, à data de vigência desta política, em fase Beta (versão 1.0). Isto significa que algumas funcionalidades poderão estar em evolução, em teste ou sujeitas a ajustes. Comprometemo-nos, ainda assim, a tratar os seus dados pessoais com o mesmo rigor e responsabilidade que aplicaríamos a um serviço em produção plena. Sempre que uma funcionalidade em teste implique um tratamento adicional ou distinto dos seus dados, procuraremos informá-lo de forma clara e, quando exigido, recolher o seu consentimento.

## 1. Introdução e âmbito

A presente Política de Privacidade descreve como a plataforma **Kuteka** (adiante designada por «Kuteka», «plataforma», «nós» ou «nosso») recolhe, utiliza, partilha, conserva e protege os dados pessoais das pessoas que utilizam os seus serviços, acessíveis através do sítio https://kutekalink.com e de eventuais aplicações associadas.

A Kuteka é uma plataforma patrimonial de modelo **B2B2C** (empresa-para-empresa-para-consumidor) que opera em Angola. Isto significa que a plataforma serve, simultaneamente, entidades profissionais (parceiros, prestadores de serviço, agentes do marketplace) e os utilizadores finais (consumidores) que com elas interagem. Em função do seu papel — utilizador final, parceiro profissional ou representante de uma entidade — o tratamento dos seus dados poderá diferir, e esta política assinala essas diferenças sempre que relevante.

Esta política aplica-se a todos os dados pessoais tratados no contexto:

- da criação e gestão de contas de utilizador;
- da utilização das funcionalidades de gestão patrimonial, do marketplace e dos serviços associados;
- dos processos de verificação de identidade e conhecimento do cliente (KYC / KIS);
- das operações de pagamento realizadas através do **Kuteka Pay**;
- das comunicações estabelecidas connosco por qualquer canal;
- da navegação e utilização técnica do sítio e das aplicações.

Ao utilizar a Kuteka, o titular dos dados reconhece ter lido e compreendido a presente política. Quando o tratamento depender do seu consentimento, este ser-lhe-á solicitado de forma autónoma, informada e inequívoca, podendo ser retirado a qualquer momento nos termos da secção 12.

Esta política não substitui os Termos e Condições de Utilização da plataforma, devendo ambos os documentos ser lidos em conjunto.

## 2. Responsável pelo tratamento e contactos

O responsável pelo tratamento dos dados pessoais recolhidos através da Kuteka é o **operador da plataforma Kuteka**, entidade que determina as finalidades e os meios do tratamento descritos nesta política.

Para qualquer questão relacionada com privacidade, protecção de dados ou exercício de direitos, disponibilizamos os seguintes contactos:

| Assunto                                               | Contacto                   |
| ----------------------------------------------------- | -------------------------- |
| Encarregado de Protecção de Dados (DPO) / privacidade | privacidade@kutekalink.com |
| Contacto geral                                        | contacto@kutekalink.com    |
| Sítio institucional                                   | https://kutekalink.com     |

Nomeámos um ponto de contacto dedicado às matérias de privacidade (função de DPO / encarregado de protecção de dados) que centraliza os pedidos dos titulares, acompanha a conformidade dos tratamentos e serve de interlocutor com a autoridade de controlo competente. Todos os pedidos relativos a esta política deverão, preferencialmente, ser dirigidos ao endereço **privacidade@kutekalink.com**.

## 3. Dados que recolhemos

A Kuteka recolhe apenas os dados necessários para prestar os seus serviços de forma segura, fiável e conforme à lei. Os dados podem ser fornecidos directamente pelo titular, gerados automaticamente pela utilização da plataforma ou obtidos junto de terceiros no âmbito de verificações legalmente exigidas (por exemplo, validação de documentos).

A tabela seguinte resume as principais categorias de dados tratados.

| Categoria                         | Exemplos de dados                                                                                                                                                                                           | Origem                                              |
| --------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **Dados de conta**                | Nome, endereço de correio electrónico, número de telefone, palavra-passe (armazenada de forma cifrada/derivada), tipo de conta e papel na plataforma                                                        | Fornecidos pelo titular                             |
| **Dados de perfil**               | Fotografia de perfil, preferências, idioma, dados de contacto complementares, informação da entidade que representa (no caso de parceiros)                                                                  | Fornecidos pelo titular                             |
| **Documentos KYC / KIS**          | Documento de identificação (bilhete de identidade, passaporte ou equivalente), número de identificação, comprovativos de morada, e — quando aplicável — selfie ou verificação biométrica de correspondência | Fornecidos pelo titular / validados por prestadores |
| **Dados financeiros**             | Dados de operações patrimoniais, movimentos, registos de transacções (ledger), informação bancária associada a levantamentos ou recebimentos, histórico de pagamentos                                       | Fornecidos pelo titular / gerados pela plataforma   |
| **Dados de utilização**           | Funcionalidades acedidas, acções realizadas, histórico de interacções, registos de actividade na conta                                                                                                      | Gerados automaticamente                             |
| **Dados de dispositivo e sessão** | Endereço IP, tipo e versão de dispositivo e navegador, sistema operativo, identificadores de sessão, tokens de autenticação, data e hora de acesso                                                          | Gerados automaticamente                             |
| **Comunicações**                  | Mensagens de apoio, pedidos submetidos, correspondência por correio electrónico ou SMS, respostas a inquéritos                                                                                              | Fornecidos pelo titular                             |

Não recolhemos deliberadamente categorias especiais de dados (por exemplo, dados relativos a saúde, convicções religiosas ou filiação política) para além do estritamente necessário à verificação de identidade. Quando o tratamento de dados biométricos for necessário para confirmar a identidade (ver secção 5), este é realizado com salvaguardas reforçadas e, sempre que a lei o exija, com o consentimento explícito do titular.

O titular é responsável pela exactidão dos dados que fornece e compromete-se a mantê-los actualizados, podendo corrigi-los a qualquer momento nos termos da secção 12.

## 4. Finalidades e bases de legitimidade

Tratamos os dados pessoais apenas para finalidades determinadas, explícitas e legítimas, e sempre com fundamento numa base de legitimidade adequada. As bases que invocamos são as seguintes:

- **Execução de contrato** — quando o tratamento é necessário para prestar os serviços que o titular solicitou, incluindo a criação e gestão da conta, a disponibilização das funcionalidades patrimoniais e do marketplace, e o processamento de pagamentos através do Kuteka Pay.
- **Cumprimento de obrigação legal** — quando a lei aplicável nos impõe determinado tratamento, designadamente em matéria de identificação de clientes (KYC / KIS), prevenção de branqueamento de capitais, obrigações fiscais e de facturação, e conservação de registos.
- **Interesse legítimo** — quando o tratamento é necessário para prosseguir interesses legítimos da plataforma ou de terceiros, desde que não prevaleçam os direitos e liberdades do titular. Incluem-se aqui a segurança da plataforma, a prevenção de fraude, a melhoria dos serviços e a gestão de reclamações.
- **Consentimento** — quando o tratamento depende de uma manifestação de vontade livre, específica, informada e inequívoca do titular, como em determinadas comunicações de marketing, em cookies não essenciais ou no tratamento de dados biométricos, quando aplicável.

A tabela seguinte relaciona as principais finalidades com as respectivas bases de legitimidade.

| Finalidade                                                         | Base de legitimidade                     |
| ------------------------------------------------------------------ | ---------------------------------------- |
| Criação, autenticação e gestão da conta                            | Execução de contrato                     |
| Verificação de identidade (KYC / KIS)                              | Obrigação legal; execução de contrato    |
| Processamento de pagamentos e manutenção do ledger                 | Execução de contrato; obrigação legal    |
| Prevenção de fraude e segurança da plataforma                      | Interesse legítimo; obrigação legal      |
| Apoio ao utilizador e gestão de comunicações                       | Execução de contrato; interesse legítimo |
| Cumprimento de obrigações fiscais e de facturação                  | Obrigação legal                          |
| Melhoria de serviços e análise estatística agregada                | Interesse legítimo                       |
| Comunicações de marketing (quando existam)                         | Consentimento                            |
| Cookies não essenciais e analítica                                 | Consentimento                            |
| Tratamento biométrico de correspondência facial (quando aplicável) | Consentimento; obrigação legal           |

Quando o tratamento assentar no interesse legítimo, o titular tem o direito de se opor por motivos relacionados com a sua situação particular, nos termos da secção 12. Quando assentar no consentimento, este pode ser retirado a qualquer momento, sem que tal comprometa a licitude do tratamento efectuado até ao momento da retirada.

## 5. KIS / KYC — tratamento especial de documentos de identidade

O cumprimento das obrigações de **conhecimento do cliente** (KYC — _Know Your Customer_ / KIS — _Know Your Investor_ ou congénere) é uma componente essencial de uma plataforma patrimonial responsável e, em muitos casos, uma exigência legal. Este tratamento merece salvaguardas reforçadas, que descrevemos nesta secção com transparência.

**Documentos de identidade.** Para verificar a identidade do titular, poderemos solicitar a apresentação de um documento de identificação válido (bilhete de identidade, passaporte ou documento equivalente), do respectivo número de identificação e, quando necessário, de comprovativos de morada. Estes documentos são recolhidos exclusivamente para fins de verificação, prevenção de fraude e cumprimento de obrigações legais.

**Biometria / selfie (quando aplicável).** Em determinados fluxos de verificação, poderemos solicitar uma fotografia do titular (selfie) para confirmar a correspondência entre a pessoa e o documento apresentado. Este processo pode envolver o tratamento de dados biométricos de correspondência facial. Quando tal ocorra:

- o tratamento é realizado apenas na medida do necessário para confirmar a identidade;
- é recolhido, quando exigido, o consentimento explícito do titular antes do tratamento;
- as imagens e os dados biométricos são objecto de medidas de segurança reforçadas e de prazos de conservação estritos.

**Dados bancários.** No âmbito das operações patrimoniais e de pagamento, poderemos tratar informação bancária associada ao titular (por exemplo, dados necessários a recebimentos ou levantamentos). Estes dados são tratados com confidencialidade e apenas para as finalidades de execução das operações e de cumprimento de obrigações legais.

**Acesso restrito.** O acesso aos documentos e dados KYC / KIS é limitado às pessoas e sistemas que dele necessitam para as finalidades acima. Aplicamos controlos técnicos e organizativos, incluindo a segregação de acessos, para minimizar o risco de acesso indevido.

Os documentos de identidade e os dados de verificação são conservados pelos prazos indicados na secção 9, mesmo após o encerramento da conta, quando a lei o exigir para efeitos de comprovação do cumprimento das obrigações de identificação.

## 6. Kuteka Pay e dados de pagamento

O **Kuteka Pay** é o serviço através do qual são processadas as operações de pagamento na plataforma. O tratamento dos dados de pagamento obedece às seguintes regras de transparência e segurança.

**Recurso a gateways de pagamento.** As operações de pagamento são processadas com recurso a fornecedores especializados (_gateways_ de pagamento) que operam sob os seus próprios padrões de segurança. Estes prestadores tratam os dados estritamente necessários à execução e validação das transacções.

**Não armazenamento do número completo do cartão.** A **Kuteka não armazena o número completo do cartão de pagamento** (PAN — _Primary Account Number_). Quando um pagamento por cartão é efectuado, os dados sensíveis do cartão são tratados directamente pelo _gateway_ de pagamento, podendo a Kuteka reter apenas referências não sensíveis (por exemplo, os últimos dígitos, a rede do cartão ou um identificador tokenizado) para fins de reconciliação e apresentação ao titular.

**Ledger de transacções.** A plataforma mantém um registo estruturado das operações (_ledger_), destinado a assegurar a integridade, a rastreabilidade e a reconciliação dos movimentos patrimoniais e financeiros. Este registo é essencial para a exactidão dos saldos, para a resolução de disputas e para o cumprimento de obrigações contabilísticas e legais.

**Finalidades.** Os dados de pagamento são tratados para executar as operações solicitadas, prevenir e detectar fraude, cumprir obrigações fiscais e de facturação e responder a reclamações ou pedidos de esclarecimento.

## 7. Cookies e tecnologias similares

A Kuteka utiliza cookies e tecnologias similares (armazenamento local, identificadores de sessão e afins) para assegurar o correcto funcionamento da plataforma e melhorar a experiência de utilização. Distinguimos as seguintes categorias:

- **Cookies essenciais** — indispensáveis ao funcionamento da plataforma, à autenticação, à manutenção da sessão e à segurança. Sem estes cookies, os serviços não podem ser prestados; por essa razão, não dependem de consentimento.
- **Cookies de preferências** — permitem recordar as escolhas do titular (por exemplo, idioma ou definições de apresentação) para personalizar a experiência.
- **Cookies de analítica** — ajudam-nos a compreender, de forma agregada, como a plataforma é utilizada, para melhorar os serviços. Estes cookies só são activados mediante consentimento, quando exigido.

**Como gerir.** O titular pode gerir as suas preferências de cookies através das definições do navegador, que permitem bloquear ou eliminar cookies, bem como, quando disponível, através do painel de preferências de cookies da própria plataforma. A recusa de cookies não essenciais não impede a utilização das funcionalidades base, mas pode limitar certas funções de personalização ou análise. A gestão dos cookies essenciais poderá afectar o funcionamento da plataforma.

## 8. Segurança

A segurança dos dados é uma prioridade permanente. Adoptamos medidas técnicas e organizativas adequadas para proteger os dados pessoais contra o acesso não autorizado, a divulgação, a alteração ou a destruição indevidas, incluindo:

- **Encriptação em trânsito** — as comunicações entre o dispositivo do titular e a plataforma são protegidas por protocolos de encriptação (por exemplo, TLS/HTTPS).
- **Segurança ao nível dos dados (RLS)** — aplicamos políticas de segurança ao nível das linhas de dados (_Row-Level Security_) para garantir que cada utilizador só acede aos dados a que tem efectivamente direito.
- **Autenticação reforçada (OTP)** — utilizamos mecanismos de verificação, incluindo códigos de uso único (OTP), para reforçar a autenticação e proteger o acesso à conta.
- **Centro de Segurança** — disponibilizamos ao titular um espaço onde pode consultar e gerir aspectos da segurança da sua conta, como sessões activas e eventos relevantes.
- **Retenção de eventos de segurança** — registamos e conservamos eventos de segurança (por exemplo, tentativas de acesso e alterações sensíveis) durante um período adequado, para efeitos de detecção de anomalias, investigação de incidentes e cumprimento de obrigações legais.

Apesar dos nossos esforços, nenhum sistema é totalmente imune a riscos. O titular desempenha também um papel essencial na segurança, devendo proteger as suas credenciais, activar os mecanismos de segurança disponíveis e comunicar-nos de imediato qualquer utilização não autorizada da sua conta. Em caso de violação de dados pessoais susceptível de originar risco para os titulares, actuaremos de acordo com as obrigações legais aplicáveis, incluindo, quando exigido, a notificação à autoridade competente e aos titulares afectados.

## 9. Conservação / retenção

Conservamos os dados pessoais apenas durante o tempo necessário para as finalidades para que foram recolhidos, incluindo o cumprimento de obrigações legais, contabilísticas ou de prevenção de fraude. Findos os prazos aplicáveis, os dados são eliminados ou anonimizados de forma segura.

A tabela seguinte indica os prazos de conservação por categoria. Os prazos legais específicos prevalecem sempre que a lei aplicável estabeleça períodos diferentes dos aqui indicados.

| Categoria de dados                                    | Prazo de conservação de referência                                                                                                                             |
| ----------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Dados de conta activa                                 | Enquanto a conta se mantiver activa                                                                                                                            |
| Dados de perfil                                       | Enquanto a conta se mantiver activa; eliminados ou anonimizados após o encerramento                                                                            |
| Documentos e dados KYC / KIS                          | Conservados durante a relação e, após o encerramento da conta, pelo período legalmente exigido para comprovação do cumprimento das obrigações de identificação |
| Registos financeiros e ledger de transacções          | Pelo período exigido pela legislação contabilística e fiscal aplicável                                                                                         |
| Dados de facturação                                   | Pelo período exigido pela legislação fiscal aplicável                                                                                                          |
| Registos (logs) de utilização e de dispositivo/sessão | Por um período limitado, adequado a fins de segurança e diagnóstico                                                                                            |
| Eventos de segurança                                  | Por um período adequado à detecção de anomalias e à investigação de incidentes                                                                                 |
| Comunicações de apoio                                 | Enquanto necessário à gestão do pedido e por período razoável posterior para efeitos de comprovação                                                            |

Após o encerramento de uma conta, procedemos à eliminação ou anonimização dos dados que já não sejam necessários, conservando apenas aqueles cuja retenção seja imposta por lei ou justificada por interesse legítimo (por exemplo, defesa em processos ou prevenção de fraude), pelos prazos estritamente necessários.

## 10. Partilha com terceiros

A Kuteka não vende dados pessoais. Partilhamos dados com terceiros apenas na medida do necessário para prestar os serviços, cumprir obrigações legais ou prosseguir interesses legítimos, e sempre com base em contratos que asseguram a confidencialidade e a protecção dos dados. As principais categorias de destinatários são:

- **Fornecedor de infra-estrutura e base de dados (Supabase)** — utilizado para alojamento de dados, autenticação e serviços associados de base de dados. Este prestador trata os dados por nossa conta e de acordo com as nossas instruções.
- **Gateways de pagamento** — fornecedores que processam as operações de pagamento realizadas através do Kuteka Pay, tratando os dados necessários à execução e validação das transacções.
- **Prestadores de SMS e correio electrónico** — utilizados para envio de códigos de verificação (OTP), notificações e comunicações operacionais.
- **Prestadores de serviço do marketplace** — parceiros e prestadores que, no contexto B2B2C, participam na prestação dos serviços disponibilizados na plataforma, recebendo os dados estritamente necessários à execução das operações.

Todos os prestadores que tratam dados por nossa conta estão vinculados por contratos que os obrigam a tratar os dados apenas de acordo com as nossas instruções, a garantir níveis adequados de segurança e a não utilizar os dados para finalidades próprias não autorizadas.

Poderemos ainda partilhar dados com autoridades públicas, judiciais ou reguladoras quando tal for exigido por lei, por decisão judicial ou para defesa de direitos legítimos.

## 11. Transferências internacionais

A Kuteka recorre a infra-estruturas de computação em nuvem (_cloud_) e a prestadores de serviço que podem estar localizados, ou tratar dados, fora de Angola. Em consequência, alguns dos seus dados poderão ser transferidos e tratados noutras jurisdições.

Sempre que ocorram transferências internacionais de dados, procuramos assegurar salvaguardas adequadas, designadamente:

- a selecção de prestadores que ofereçam garantias de segurança e de protecção de dados;
- a celebração de contratos que imponham obrigações de confidencialidade e de protecção equivalentes às aplicáveis na origem;
- a limitação das transferências ao estritamente necessário para as finalidades descritas nesta política.

Adoptamos estas medidas com inspiração nas boas práticas internacionais de protecção de dados, procurando que o nível de protecção dos seus dados não seja comprometido pelo facto de serem tratados noutra jurisdição.

## 12. Direitos do titular

Nos termos da legislação aplicável, e alinhando-nos com as boas práticas internacionais de protecção de dados, o titular dos dados pode exercer os seguintes direitos:

- **Direito de acesso** — obter confirmação de que os seus dados são tratados e aceder a esses dados;
- **Direito de rectificação** — obter a correcção de dados inexactos ou a actualização de dados incompletos;
- **Direito ao apagamento** — solicitar a eliminação dos seus dados, quando já não sejam necessários ou quando o tratamento seja indevido, sem prejuízo das obrigações legais de conservação;
- **Direito de oposição** — opor-se ao tratamento fundado em interesse legítimo, por motivos relacionados com a sua situação particular, bem como ao tratamento para fins de marketing directo;
- **Direito à portabilidade** — receber os dados que forneceu, num formato estruturado e de uso corrente, e, quando tecnicamente possível, solicitar a sua transmissão a outro responsável;
- **Direito de retirar o consentimento** — retirar, a qualquer momento, o consentimento anteriormente prestado, sem que tal afecte a licitude do tratamento efectuado até essa data;
- **Direito de reclamação** — apresentar reclamação junto da autoridade de controlo competente em matéria de protecção de dados.

O exercício destes direitos pode estar sujeito a limites previstos na lei, designadamente quando colida com obrigações legais de conservação ou com direitos de terceiros.

## 13. Como exercer direitos

Para exercer qualquer dos direitos descritos na secção 12, o titular deve dirigir o seu pedido ao endereço **privacidade@kutekalink.com**, indicando:

- o direito que pretende exercer;
- os dados ou o tratamento a que o pedido se refere;
- os elementos necessários à confirmação da sua identidade.

Poderemos solicitar informação adicional para confirmar a identidade do requerente, de forma a evitar a divulgação indevida de dados a terceiros. Responderemos aos pedidos dentro de um prazo razoável e conforme os prazos legais aplicáveis. O exercício destes direitos é, em regra, gratuito, salvo nos casos de pedidos manifestamente infundados ou excessivos, em que poderá ser aplicada uma taxa razoável ou recusada a resposta, nos termos da lei.

Caso o titular considere que os seus direitos não foram devidamente respeitados, tem o direito de apresentar reclamação junto da autoridade de controlo competente em matéria de protecção de dados em Angola.

## 14. Menores

A plataforma Kuteka destina-se a pessoas maiores de idade, com capacidade legal para celebrar contratos e utilizar serviços patrimoniais e de pagamento. Não recolhemos deliberadamente dados de menores.

Caso venhamos a tomar conhecimento de que recolhemos, inadvertidamente, dados de um menor sem o adequado suporte legal, procederemos à sua eliminação com a maior brevidade possível. Se um representante legal considerar que um menor sob a sua responsabilidade nos forneceu dados pessoais, deverá contactar-nos através de **privacidade@kutekalink.com** para que possamos tomar as medidas adequadas.

## 15. Alterações à política

A presente política poderá ser actualizada para reflectir alterações nos serviços, nas práticas de tratamento de dados ou nas obrigações legais aplicáveis. Sempre que introduzirmos alterações relevantes, publicaremos a versão actualizada em https://kutekalink.com, com indicação da respectiva data de vigência.

Tratando-se de uma plataforma em fase Beta, poderão ocorrer actualizações com maior frequência à medida que os serviços evoluem. Recomendamos a consulta periódica desta política. Quando as alterações implicarem tratamentos que dependam de consentimento, este ser-lhe-á solicitado de forma autónoma antes da respectiva aplicação.

## 16. Contactos

Para qualquer questão, pedido ou reclamação relacionada com esta Política de Privacidade ou com o tratamento dos seus dados pessoais, utilize os seguintes contactos:

| Assunto                                               | Contacto                   |
| ----------------------------------------------------- | -------------------------- |
| Privacidade / Encarregado de Protecção de Dados (DPO) | privacidade@kutekalink.com |
| Contacto geral                                        | contacto@kutekalink.com    |
| Sítio institucional                                   | https://kutekalink.com     |

---

_Esta Política de Privacidade foi elaborada com base na legislação angolana aplicável à protecção de dados pessoais e inspirada em boas práticas internacionais de protecção de dados, incluindo os princípios subjacentes ao Regulamento Geral sobre a Protecção de Dados (RGPD/GDPR) e à Lei Geral de Protecção de Dados (LGPD). Esta referência é feita a título de alinhamento de princípios e boas práticas, não constituindo qualquer declaração de certificação formal de conformidade com esses regimes._

**Luanda, 5 de Agosto de 2026.**
